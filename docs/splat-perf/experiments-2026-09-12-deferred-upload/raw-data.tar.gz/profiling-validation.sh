cd /mnt/data2/cesium-splat-perf/cesiumjs
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/chrome-gl timeout -k 10 180 npm run test -- --browsers Chrome --includeName GaussianSplat --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/profiling-tests.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/profiling-tests.done
