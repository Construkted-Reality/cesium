while test ! -f /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/full-final.done; do sleep 2; done
cd /mnt/data2/cesium-splat-perf/cesiumjs
npx prettier --write packages/engine/Source/Scene/GaussianSplatPrimitive.js packages/engine/Specs/Scene/GaussianSplatPrimitiveSpec.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/wake-format.log 2>&1
npm run build > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/wake-build.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/wake-build.done
cp Build/CesiumUnminified/Cesium.js /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/wake-Cesium.js
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/chrome-gl timeout -k 10 180 npm run test -- --browsers Chrome --includeName GaussianSplat --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/wake-tests.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/wake-tests.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/lifecycle-debug.mjs wake-cold wake-Cesium.js idle > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/wake-cold.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/wake-cold.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/lifecycle-debug.mjs wake-warm wake-Cesium.js warm-idle > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/wake-warm.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/wake-warm.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/lifecycle-debug.mjs wake-failure wake-Cesium.js failure > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/wake-failure.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/wake-failure.done
