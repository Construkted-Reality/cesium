while test ! -f /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/wake-failure.done; do sleep 2; done
python3 /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/driver-memory.py driver-b1 baseline-Cesium.js
python3 /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/driver-memory.py driver-c1 wake-Cesium.js
python3 /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/driver-memory.py driver-c2 wake-Cesium.js
python3 /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/driver-memory.py driver-b2 baseline-Cesium.js
cd /mnt/data2/cesium-splat-perf/cesiumjs
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/chrome-gl timeout -k 10 300 npm run test -- --browsers Chrome --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/full-wake.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/full-wake.done
