while test ! -f /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/profiling-tests.done; do sleep 2; done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/context-loss.mjs context-loss-source wake-Cesium.js context > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/context-loss-source.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/context-loss-source.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/context-loss.mjs context-loss-baseline baseline-Cesium.js context > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/context-loss-baseline.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/context-loss-baseline.done
