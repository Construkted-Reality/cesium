while test ! -f /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/bike-c1.done; do sleep 2; done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/lifecycle.mjs idle-source source-Cesium.js idle > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/idle-source.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/idle-source.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/lifecycle.mjs failure-source source-Cesium.js failure > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/failure-source.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/failure-source.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/lifecycle.mjs idle-baseline baseline-Cesium.js idle > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/idle-baseline.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/idle-baseline.done
