from pathlib import Path
import ctypes,json,subprocess,time,sys
d=Path('/mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload')
label,bundle=sys.argv[1:3]
nv=ctypes.CDLL('libnvidia-ml.so.1')
assert nv.nvmlInit_v2()==0
handle=ctypes.c_void_p()
assert nv.nvmlDeviceGetHandleByIndex_v2(0,ctypes.byref(handle))==0
class Memory(ctypes.Structure):
 _fields_=[('total',ctypes.c_ulonglong),('free',ctypes.c_ulonglong),('used',ctypes.c_ulonglong)]
def used():
 m=Memory();assert nv.nvmlDeviceGetMemoryInfo(handle,ctypes.byref(m))==0;return m.used
result={'label':label,'beforeBytes':used(),'samples':[],'gpuBefore':subprocess.run(['nvidia-smi'],capture_output=True,text=True).stdout}
with open(d/(label+'.log'),'w') as log:
 p=subprocess.Popen(['node',str(d/'fixed-cpu.mjs'),label,bundle],stdout=log,stderr=subprocess.STDOUT)
 while p.poll() is None:
  result['samples'].append({'time':time.time(),'bytes':used()})
  time.sleep(.02)
 result['exitCode']=p.returncode
 for _ in range(100):
  result['samples'].append({'time':time.time(),'bytes':used()});time.sleep(.02)
result['afterBytes']=used()
result['peakBytes']=max(x['bytes'] for x in result['samples'])
(d/(label+'-nvml.json')).write_text(json.dumps(result))
(d/(label+'.done')).write_text(str(p.returncode))
nv.nvmlShutdown()
