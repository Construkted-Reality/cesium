while test ! -f /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/source64.done; do sleep 2; done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/fixed.mjs fixed-baseline baseline-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/fixed-baseline.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/fixed-baseline.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/fixed.mjs fixed-source source-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/fixed-source.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/fixed-source.done
