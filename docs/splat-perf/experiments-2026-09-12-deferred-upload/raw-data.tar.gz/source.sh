cd /mnt/data2/cesium-splat-perf/cesiumjs
npx prettier --write packages/engine/Specs/Scene/GaussianSplatPrimitiveSpec.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/format.log 2>&1
npx eslint packages/engine/Source/Scene/GaussianSplatPrimitive.js packages/engine/Specs/Scene/GaussianSplatPrimitiveSpec.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/lint.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/lint.done
npm run build > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/source-build.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/source-build.done
cp Build/CesiumUnminified/Cesium.js /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/source-Cesium.js
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/chrome-gl timeout 180 npm run test -- --browsers Chrome --includeName GaussianSplat --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/splat-tests.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/splat-tests.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/probe.mjs source64 64 30 source-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/source64.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/source64.done
