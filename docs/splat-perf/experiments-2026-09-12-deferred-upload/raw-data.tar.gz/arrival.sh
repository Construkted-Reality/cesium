while test ! -f /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/idle-baseline.done; do sleep 2; done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/fixed-cpu.mjs geo-arrival1 arrival-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/geo-arrival1.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/geo-arrival1.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/fixed-cpu.mjs geo-arrival2 arrival-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/geo-arrival2.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/geo-arrival2.done
