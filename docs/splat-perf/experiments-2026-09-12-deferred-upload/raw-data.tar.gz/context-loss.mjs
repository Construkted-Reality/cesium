import {chromium} from '/mnt/data2/cesium-splat-perf/cesiumjs/node_modules/@playwright/test/index.mjs';
import {readFileSync,writeFileSync} from 'node:fs';
const dir='/mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload';
const [label,bundle,mode='idle']=process.argv.slice(2);
const result={label,mode,errors:[],renderErrors:[]};
const browser=await chromium.launch({channel:'chromium',headless:false,args:['--no-sandbox','--use-angle=gl','--ozone-platform=wayland'],env:{...process.env,XDG_RUNTIME_DIR:dir+'/wayland',WAYLAND_DISPLAY:'splat-wayland'}});
let page;
try{
 page=await browser.newPage({viewport:{width:1920,height:1080}});page.on('pageerror',e=>result.errors.push(e.message));
 await page.route('**/Build/CesiumUnminified/Cesium.js',r=>r.fulfill({body:readFileSync(dir+'/'+bundle),contentType:'text/javascript'}));
 await page.goto('http://localhost:8099/tools/splat-perf/loading-harness.html?tileset=/splat-data/oracle-run/geo-newdefault/tileset.json&tileCache=1073741824&sse=4&mode=static&capture=1');
 await page.waitForFunction(()=>window.__round2Tilesets?.length,null,{timeout:30000});
 await page.evaluate(mode=>{
  window.__renderErrors=[];window.__faults=0;window.__seenUploads=[];
  __scene.renderError.addEventListener((scene,error)=>__renderErrors.push(String(error)));
  if(mode==='idle'){__scene.requestRenderMode=true;__scene.maximumRenderTimeChange=Infinity;}
 },mode);
 const wait=async count=>page.waitForFunction(count=>{const t=__round2Tilesets[0],p=t.gaussianSplatPrimitive;return p?._numSplats===count&&!p._pendingSnapshot&&!p._needsSnapshotRebuild&&t.tilesLoaded;},count,{timeout:45000});
 await wait(2087136);
 if(mode==='warm-idle'){await page.evaluate(()=>{__scene.requestRenderMode=true;__scene.maximumRenderTimeChange=Infinity;});}
 result.cold=await page.evaluate(()=>({splats:__round2Tilesets[0].gaussianSplatPrimitive._numSplats,frame:__scene.frameState.frameNumber}));
 await page.evaluate(()=>{const gl=__scene.context._gl;const ext=gl.getExtension('WEBGL_lose_context');if(!ext)throw new Error('Missing context loss extension');ext.loseContext();});
 await page.waitForTimeout(250);
 result.disposal=await page.evaluate(()=>{const t=__round2Tilesets[0],p=t.gaussianSplatPrimitive;const lost=__scene.context._gl.isContextLost();__scene.primitives.remove(t);return {lost,primitiveDestroyed:p.isDestroyed(),tilesetDestroyed:t.isDestroyed(),textures:p._texturesByteLength,geometry:p._geometryByteLength,renderErrors:__renderErrors};});

}catch(e){result.failure=String(e);result.state=await page.evaluate(()=>{const t=__round2Tilesets[0],p=t.gaussianSplatPrimitive;return {renderErrors:__renderErrors,selected:t._selectedTiles.length,ready:t.statistics.numberOfTilesWithContentReady,processing:t.statistics.numberOfTilesProcessing,requests:t.statistics.numberOfPendingRequests,splats:p?._numSplats,pending:p?._pendingSnapshot?.state,needsRebuild:p?._needsSnapshotRebuild,stable:p?._selectedTilesStableFrames,requested:__scene._renderRequested};});process.exitCode=1;}
finally{writeFileSync(dir+'/'+label+'.json',JSON.stringify(result));await browser.close();}
