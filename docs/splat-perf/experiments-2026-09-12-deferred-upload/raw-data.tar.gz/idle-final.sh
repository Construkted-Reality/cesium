while test ! -f /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/full-wake.done; do sleep 2; done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/lifecycle-idle.mjs wake-idle-final wake-Cesium.js idle > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/wake-idle-final.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/wake-idle-final.done
