cd /mnt/data2/cesium-splat-perf/cesiumjs
npm run build > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/prototype-build.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/prototype-build.done
cp Build/CesiumUnminified/Cesium.js /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/prototype-Cesium.js
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/probe.mjs prototype64 64 30 prototype-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/prototype64.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/prototype64.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/probe.mjs baseline64 64 30 baseline-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/baseline64.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/baseline64.done
