while test ! -f /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/fixed-source.done; do sleep 2; done
cd /mnt/data2/cesium-splat-perf/cesiumjs
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/chrome-gl timeout 120 npm run test -- --browsers Chrome --includeName "keeps the old texture" --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/upload-debug.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/upload-debug.done
