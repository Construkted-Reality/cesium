cd /mnt/data2/cesium-splat-perf/cesiumjs
npx prettier --write packages/engine/Source/Scene/GaussianSplatPrimitive.js packages/engine/Specs/Scene/GaussianSplatPrimitiveSpec.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/final-format.log 2>&1
npm run build > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/final-build.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/final-build.done
cp Build/CesiumUnminified/Cesium.js /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/source-Cesium.js
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/chrome-gl timeout 180 npm run test -- --browsers Chrome --includeName GaussianSplat --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/splat-final.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/splat-final.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/lifecycle-debug.mjs warm-idle-source source-Cesium.js warm-idle > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/warm-idle-source.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/warm-idle-source.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/lifecycle-debug.mjs cold-debug-source source-Cesium.js idle > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/cold-debug-source.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/cold-debug-source.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/lifecycle-debug.mjs cold-debug-baseline baseline-Cesium.js idle > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/cold-debug-baseline.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/cold-debug-baseline.done
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/chrome-gl timeout -k 10 300 npm run test -- --browsers Chrome --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/full-final.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/full-final.done
