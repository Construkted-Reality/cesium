import {chromium} from '/mnt/data2/cesium-splat-perf/cesiumjs/node_modules/@playwright/test/index.mjs';
import {readFileSync,writeFileSync} from 'node:fs';
const dir='/mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload';
const [label,bundle,mode='idle']=process.argv.slice(2);
const result={label,mode,errors:[],renderErrors:[]};
const browser=await chromium.launch({channel:'chromium',headless:false,args:['--no-sandbox','--use-angle=gl','--ozone-platform=wayland'],env:{...process.env,XDG_RUNTIME_DIR:dir+'/wayland',WAYLAND_DISPLAY:'splat-wayland'}});
try{
 const page=await browser.newPage({viewport:{width:1920,height:1080}});page.on('pageerror',e=>result.errors.push(e.message));
 await page.route('**/Build/CesiumUnminified/Cesium.js',r=>r.fulfill({body:readFileSync(dir+'/'+bundle),contentType:'text/javascript'}));
 await page.goto('http://localhost:8099/tools/splat-perf/loading-harness.html?tileset=/splat-data/oracle-run/geo-newdefault/tileset.json&tileCache=1073741824&sse=4&mode=static&capture=1');
 await page.waitForFunction(()=>window.__round2Tilesets?.length,null,{timeout:30000});
 await page.evaluate(mode=>{
  window.__renderErrors=[];window.__faults=0;window.__seenUploads=[];
  __scene.renderError.addEventListener((scene,error)=>__renderErrors.push(String(error)));
  if(mode==='idle'){__scene.requestRenderMode=true;__scene.maximumRenderTimeChange=Infinity;}
 },mode);
 const wait=async count=>page.waitForFunction(count=>{const t=__round2Tilesets[0],p=t.gaussianSplatPrimitive;return p?._numSplats===count&&!p._pendingSnapshot&&!p._needsSnapshotRebuild&&t.tilesLoaded;},count,{timeout:45000});
 await wait(2087136);
 result.cold=await page.evaluate(()=>({splats:__round2Tilesets[0].gaussianSplatPrimitive._numSplats,frame:__scene.frameState.frameNumber}));
 if(mode==='failure'){
  await page.evaluate(()=>{
   const original=Cesium.GaussianSplatPrimitive.buildGSplatDrawCommand;
   Cesium.GaussianSplatPrimitive.buildGSplatDrawCommand=function(p,...args){
    if(!__faults){__faults++;__seenUploads.push(p.gaussianSplatTexture);throw new Error('Injected upload commit failure');}
    return original.call(this,p,...args);
   };
  });
 }
 await page.evaluate(()=>{__round2Tilesets[0].maximumScreenSpaceError=8;__scene.requestRender();});
 await wait(1301102);
 result.replacement=await page.evaluate(()=>({splats:__round2Tilesets[0].gaussianSplatPrimitive._numSplats,faults:__faults,failedTexturesDestroyed:__seenUploads.every(x=>x.isDestroyed()),renderErrors:__renderErrors}));
 await page.evaluate(()=>{__round2Tilesets[0].maximumScreenSpaceError=4;__scene.requestRender();});
 await wait(2087136);
 result.recovered=await page.evaluate(()=>({splats:__round2Tilesets[0].gaussianSplatPrimitive._numSplats,renderErrors:__renderErrors}));
}catch(e){result.failure=String(e);process.exitCode=1;}
finally{writeFileSync(dir+'/'+label+'.json',JSON.stringify(result));await browser.close();}
