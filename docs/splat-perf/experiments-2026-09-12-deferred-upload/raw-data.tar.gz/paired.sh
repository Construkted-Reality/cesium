cd /mnt/data2/cesium-splat-perf/cesiumjs
npx prettier --write packages/engine/Specs/Scene/GaussianSplatPrimitiveSpec.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/format2.log 2>&1
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/chrome-gl timeout 180 npm run test -- --browsers Chrome --includeName GaussianSplat --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/splat-tests2.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/splat-tests2.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/fixed-pixels.mjs geo-b1 baseline-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/geo-b1.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/geo-b1.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/fixed-pixels.mjs geo-c1 source-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/geo-c1.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/geo-c1.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/fixed-pixels.mjs geo-c2 source-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/geo-c2.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/geo-c2.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/fixed-pixels.mjs geo-b2 baseline-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/geo-b2.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/geo-b2.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/fixed-pixels.mjs bike-b1 baseline-Cesium.js bike > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/bike-b1.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/bike-b1.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/fixed-pixels.mjs bike-c1 source-Cesium.js bike > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/bike-c1.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-deferred-upload/bike-c1.done
