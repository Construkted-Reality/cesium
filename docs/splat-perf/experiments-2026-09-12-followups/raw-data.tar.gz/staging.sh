cd /mnt/data2/cesium-splat-perf/cesiumjs
npx prettier --write packages/engine/Source/Scene/GaussianSplatPrimitive.js packages/engine/Source/Workers/gaussianSplatTextureGenerator.js packages/engine/Specs/Scene/GaussianSplatPrimitiveSpec.js packages/engine/Specs/Scene/GaussianSplatTextureGeneratorSpec.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/padding-format.log 2>&1
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/chrome-gl timeout -k 10 180 npm run test -- --browsers Chrome --includeName GaussianSplat --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/padding-final-tests.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/padding-final-tests.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/prefetch.mjs prefetch-geo padding-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/prefetch-geo.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/prefetch-geo.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/prefetch.mjs prefetch-bike padding-Cesium.js bike > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/prefetch-bike.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/prefetch-bike.done
