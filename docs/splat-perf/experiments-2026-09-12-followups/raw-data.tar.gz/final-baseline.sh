cd /mnt/data2/cesium-splat-perf/cesiumjs
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/reentry-memory.mjs dispose-current-baseline-2 baseline-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/dispose-current-baseline-2.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/dispose-current-baseline-2.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/reentry-memory.mjs dispose-lifetime-repeat-2 lifetime-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/dispose-lifetime-repeat-2.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/dispose-lifetime-repeat-2.done
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/chrome-gl timeout -k 10 300 npm run test -- --browsers Chrome --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/full-current-baseline.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/full-current-baseline.done