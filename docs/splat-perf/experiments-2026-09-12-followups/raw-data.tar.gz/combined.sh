node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/reentry-memory.mjs dispose-combined combined-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/dispose-combined.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/dispose-combined.done
