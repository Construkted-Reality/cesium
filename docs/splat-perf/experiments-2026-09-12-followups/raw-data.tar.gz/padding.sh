cd /mnt/data2/cesium-splat-perf/cesiumjs
npm run build > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/padding-build.log 2>&1
code=$?; echo $code > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/padding-build.done
[ "$code" = 0 ] || exit "$code"
cp Build/CesiumUnminified/Cesium.js /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/padding-Cesium.js
cp -r Build/CesiumUnminified/Workers /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/padding-Workers
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/profile.mjs profile-padding padding-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/profile-padding.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/profile-padding.done
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/chrome-gl timeout -k 10 180 npm run test -- --browsers Chrome --includeName GaussianSplat --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/padding-tests.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/padding-tests.done
