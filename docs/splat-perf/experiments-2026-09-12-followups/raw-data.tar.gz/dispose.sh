cd /mnt/data2/cesium-splat-perf/cesiumjs
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/chrome-gl timeout -k 10 180 npm run test -- --browsers Chrome --includeName GaussianSplatStress --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/stress-specs.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/stress-specs.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/dispose-memory.mjs dispose-baseline padding-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/dispose-baseline.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/dispose-baseline.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/dispose-memory.mjs dispose-release padding-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/dispose-release.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/dispose-release.done
