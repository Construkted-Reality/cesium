node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/memory.mjs memory-geo padding-Cesium.js geo > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/memory-geo.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/memory-geo.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/release-worker.mjs release-geo padding-Cesium.js geo > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/release-geo.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/release-geo.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/memory.mjs memory-bike padding-Cesium.js bike > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/memory-bike.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/memory-bike.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/release-worker.mjs release-bike padding-Cesium.js bike > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/release-bike.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/release-bike.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/context-recovery.mjs context-continuous baseline-Cesium.js continuous > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/context-continuous.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/context-continuous.done