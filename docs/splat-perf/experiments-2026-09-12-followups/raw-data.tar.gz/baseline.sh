cd /mnt/data2/cesium-splat-perf/cesiumjs
npm run build > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/baseline-build.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/baseline-build.done
cp Build/CesiumUnminified/Cesium.js /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/baseline-Cesium.js
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/profile.mjs profile-baseline baseline-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/profile-baseline.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/profile-baseline.done
