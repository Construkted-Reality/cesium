cd /mnt/data2/cesium-splat-perf/cesiumjs
npm run build > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/lifetime-build.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/lifetime-build.done
cp Build/CesiumUnminified/Cesium.js /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/lifetime-Cesium.js
cp -r Build/CesiumUnminified/Workers /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/lifetime-Workers
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/chrome-gl timeout -k 10 180 npm run test -- --browsers Chrome --includeName GaussianSplat --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/lifetime-tests.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/lifetime-tests.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/dispose-memory.mjs dispose-lifetime lifetime-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/dispose-lifetime.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/dispose-lifetime.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/stress.mjs stress-lifetime lifetime-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/stress-lifetime.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/stress-lifetime.done
