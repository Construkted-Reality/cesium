node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/stress.mjs stress-baseline baseline-Cesium.js  > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/stress-baseline.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/stress-baseline.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/stress.mjs stress-padding padding-Cesium.js  > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/stress-padding.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/stress-padding.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/context-recovery.mjs context-baseline baseline-Cesium.js warm-idle > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/context-baseline.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/context-baseline.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/context-recovery.mjs context-guarded padding-Cesium.js guarded > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/context-guarded.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/context-guarded.done