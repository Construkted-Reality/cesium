cd /mnt/data2/cesium-splat-perf/cesiumjs
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/chrome-gl timeout -k 10 180 npm run test -- --browsers Chrome --includeName GaussianSplat --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/lifetime-final-tests.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/lifetime-final-tests.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/reentry-memory.mjs dispose-current-baseline baseline-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/dispose-current-baseline.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/dispose-current-baseline.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/reentry-memory.mjs dispose-lifetime-repeat lifetime-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/dispose-lifetime-repeat.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/dispose-lifetime-repeat.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/context-recovery.mjs context-final baseline-Cesium.js guarded > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/context-final.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/context-final.done