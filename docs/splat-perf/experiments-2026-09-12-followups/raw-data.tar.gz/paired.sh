node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/profile.mjs baseline-repeat baseline-Cesium.js geo > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/baseline-repeat.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/baseline-repeat.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/profile.mjs padding-repeat padding-Cesium.js geo > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/padding-repeat.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/padding-repeat.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/profile.mjs baseline-bike baseline-Cesium.js bike > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/baseline-bike.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/baseline-bike.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/profile.mjs padding-bike padding-Cesium.js bike > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/padding-bike.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/padding-bike.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/trim.mjs trim-geo padding-Cesium.js geo > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/trim-geo.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/trim-geo.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/trim.mjs trim-bike padding-Cesium.js bike > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/trim-bike.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-followups/trim-bike.done