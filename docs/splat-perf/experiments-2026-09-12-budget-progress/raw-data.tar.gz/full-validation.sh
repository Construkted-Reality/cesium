while test ! -f /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/bike-source16.done; do sleep 2; done
cd /mnt/data2/cesium-splat-perf/cesiumjs
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/chrome-gl timeout 300 npm run test -- --browsers Chrome --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/full-candidate.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/full-candidate.done
cd /mnt/data2/cesium-splat-perf/research-budget-progress
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/chrome-gl timeout 300 npm run test -- --browsers Chrome --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/full-baseline.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/full-baseline.done
