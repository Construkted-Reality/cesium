cd /mnt/data2/cesium-splat-perf/cesiumjs
npx prettier --write packages/engine/Source/Scene/Cesium3DTileset.js packages/engine/Source/Scene/Cesium3DTilesetBaseTraversal.js packages/engine/Source/Scene/Cesium3DTilesetSkipTraversal.js packages/engine/Specs/Scene/Cesium3DTilesetSpec.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/format.log 2>&1
npx eslint packages/engine/Source/Scene/Cesium3DTileset.js packages/engine/Source/Scene/Cesium3DTilesetBaseTraversal.js packages/engine/Source/Scene/Cesium3DTilesetSkipTraversal.js packages/engine/Specs/Scene/Cesium3DTilesetSpec.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/lint.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/lint.done
npm run build > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/source-build.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/source-build.done
cp Build/CesiumUnminified/Cesium.js /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/fallback-source-Cesium.js
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/chrome-gl timeout 240 npm run test -- --browsers Chrome --includeName Cesium3DTileset --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/tileset-tests.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/tileset-tests.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/probe.mjs source0 0 25 fallback-source-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/source0.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/source0.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/probe.mjs source64 64 25 fallback-source-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/source64.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/source64.done
