set -e
npm run build
cp Build/CesiumUnminified/Cesium.js /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/baseline-Cesium.js
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/probe.mjs baseline0 0 25
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/probe.mjs baseline64 64 25
touch /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/baseline.done
