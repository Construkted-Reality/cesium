while test ! -f /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/source64.done; do sleep 2; done
cd /mnt/data2/cesium-splat-perf/cesiumjs
npx prettier --write packages/engine/Specs/Scene/Cesium3DTilesetSpec.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/format-final.log 2>&1
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/chrome-gl timeout 240 npm run test -- --browsers Chrome --includeName Cesium3DTileset --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/tileset-final.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/tileset-final.done
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/chrome-gl timeout 240 npm run test -- --browsers Chrome --includeName GaussianSplat --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/splat-final.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/splat-final.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/probe-bike.mjs bike-source0 0 30 fallback-source-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/bike-source0.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/bike-source0.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/probe-bike.mjs bike-source16 16 30 fallback-source-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/bike-source16.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/bike-source16.done
