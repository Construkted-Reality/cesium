while test ! -f /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/admit64.done; do sleep 2; done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/probe.mjs fallback0 0 25 fallback-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/fallback0.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/fallback0.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/probe.mjs fallback64 64 25 fallback-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/fallback64.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/fallback64.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/probe.mjs reserve64 64 25 reserve-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/reserve64.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/reserve64.done
