while test ! -f /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/equal-root0.done; do sleep 2; done
cd /mnt/data2/cesium-splat-perf/research-budget-progress
npm run build > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/baseline-worktree-build.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/baseline-worktree-build.done
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/chrome-gl timeout 300 npm run test -- --browsers Chrome --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/full-baseline-retry.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/full-baseline-retry.done
