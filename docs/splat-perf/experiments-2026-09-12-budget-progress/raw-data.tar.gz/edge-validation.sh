while test ! -f /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/full-baseline.done; do sleep 2; done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/probe-move.mjs move-source0 0 25 fallback-source-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/move-source0.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/move-source0.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/probe-equal-root.mjs equal-root0 0 25 fallback-source-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/equal-root0.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/equal-root0.done
