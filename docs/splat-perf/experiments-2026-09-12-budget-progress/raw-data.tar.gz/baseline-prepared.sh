while test ! -f /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/full-baseline-retry.done; do sleep 2; done
cd /mnt/data2/cesium-splat-perf/research-budget-progress
npx gulp prepare > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/baseline-prepare.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/baseline-prepare.done
CHROME_BIN=/mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/chrome-gl timeout 300 npm run test -- --browsers Chrome --failTaskOnError --suppressPassed > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/full-baseline-prepared.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/full-baseline-prepared.done
