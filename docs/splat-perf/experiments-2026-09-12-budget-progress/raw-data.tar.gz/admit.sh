node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/probe.mjs admit0 0 25 admit-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/admit0.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/admit0.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/probe.mjs admit64 64 25 admit-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/admit64.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/admit64.done
