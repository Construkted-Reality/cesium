while test ! -f /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/baseline.done; do sleep 2; done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/probe.mjs progress0 0 25 progress-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/progress0.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/progress0.done
node /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/probe.mjs progress64 64 25 progress-Cesium.js > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/progress64.log 2>&1
echo $? > /mnt/data2/cesium-splat-perf/experiments-2026-09-12-budget-progress/progress64.done
